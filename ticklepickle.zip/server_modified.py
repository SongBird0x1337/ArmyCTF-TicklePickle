#!/usr/bin/python3
# Security Checks Applied : 
# 1. Encrypt the file with symmetric encryption
# 2. Client will set the permission to the key file and user.json
# 3. Check which user is running the program, so no third party can write the users.json file

import pickle
from cryptography.fernet import Fernet
import getpass

def user_check():
    return getpass.getuser()

def Decryptor(file_path , keyfile):
    with open(keyfile , 'rb') as kFile:
        key = Fernet(kFile.read())
    with open(file_path ,'rb') as eFile:
        eContent = eFile.read()

    pContent = key.decrypt(eContent);
    return pContent
def reverse_fun(pContent):
      d = pickle.loads(pContent)
      return d

if __name__ == '__main__':
    if user_check() != 'root':
        print("Unauthorized Access: Trusted User only")
        exit(1);

    print(reverse_fun(Decryptor("users.json","secret.key")))
