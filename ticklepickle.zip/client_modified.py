#!/usr/bin/python3
# Security Checks Applied :
# 1. Encrypt the file with symmetric encryption
# 2. Client will set the permission to the key file and user.json
# 3. Check which user is running the program, so no third party can write the users.json file

from os import chmod
import stat
import pickle
from cryptography.fernet import Fernet
import getpass
def user_check():
    return getpass.getuser()
def encrypt_file(file_path):
    key = Fernet.generate_key()
    with open('secret.key' , 'wb') as keyfile:
        keyfile.write(key)

    chmod('secret.key' , stat.S_IRUSR );
    fernet = Fernet(key)

    with open(file_path , 'rb') as pFile:
        pContent = pFile.read()

    eContent = fernet.encrypt(pContent)

    with open(file_path , "wb") as eFile:
        eFile.write(eContent);
    chmod(file_path , stat.S_IRUSR);

def fun(name,password):
    s = {"username":name,"password":password}
    safecode = pickle.dumps(s)
    with open("users.json","wb") as f:
        f.write(safecode)
    return safecode

if __name__ == '__main__':
    if user_check() != 'root':
        print("Unauthorized Access: Trusted User only")
        exit(1);
    u = input("Username : ")
    p = input("Password : ")
    fun(u,p)
    encrypt_file("users.json")
